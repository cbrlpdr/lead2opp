export type SortField = "score" | "name" | "company"
export type SortOrder = "asc" | "desc"
