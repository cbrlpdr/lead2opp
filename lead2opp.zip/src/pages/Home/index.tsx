import MainContainer from "../../components/MainContainer";
import Navbar from "../../components/Navbar"

export default function Home() {
    return (
        <>
        <Navbar />
        <MainContainer />
        </>
    );
}
